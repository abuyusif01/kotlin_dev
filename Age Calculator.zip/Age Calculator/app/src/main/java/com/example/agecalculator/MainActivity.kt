package com.example.agecalculator

import android.annotation.SuppressLint
import android.net.wifi.p2p.WifiP2pManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.ActionMenuView
import android.widget.Button
import android.widget.Toast
import java.sql.Time
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }


   fun clickedSelectDate(view: View)
   {

       val c = Calendar.getInstance()
       val year = c.get(Calendar.YEAR)
       val month = c.get(Calendar.MONTH)
       val day = c.get(Calendar.DAY_OF_MONTH)
       val hour = c.get(Calendar.HOUR)
       val min = c.get(Calendar.MINUTE)
       val sec = c.get(Calendar.SECOND)
       findViewById<Button>(R.id.x_zero).text = "$year"
       findViewById<Button>(R.id.x_one).text = "$month"
       findViewById<Button>(R.id.x_two).text = "$day"
       findViewById<Button>(R.id.x_three).text = "$hour"
       findViewById<Button>(R.id.x_four).text = "$min"
       findViewById<Button>(R.id.x_five).text = "$sec"

   }

    fun clickedReset(view: View)
    {
        Toast.makeText(this, "Clicked Reset button", Toast.LENGTH_SHORT).show()
        findViewById<Button>(R.id.x_zero).text = ""
        findViewById<Button>(R.id.x_one).text = ""
        findViewById<Button>(R.id.x_two).text = ""
        findViewById<Button>(R.id.x_three).text = ""
        findViewById<Button>(R.id.x_four).text = ""
        findViewById<Button>(R.id.x_five).text = ""
    }

}
