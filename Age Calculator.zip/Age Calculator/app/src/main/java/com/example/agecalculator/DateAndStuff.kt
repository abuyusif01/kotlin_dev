package com.example.agecalculator
import android.os.Handler
import java.text.SimpleDateFormat
import java.util.*
import kotlin.concurrent.schedule

fun main() {

//    val c = Calendar.getInstance()
//    val year = c.get(Calendar.YEAR)
//    val month = c.get(Calendar.MONTH)
//    val day = c.get(Calendar.DAY_OF_MONTH)
//    val hour = c.get(Calendar.HOUR)
//    val min = c.get(Calendar.MINUTE)
//    print("Year is: $year\nMonth is: $month\nDay is: $day\nHour is: $hour\nMinutes is: $min")

    while ( true)
    {
        Timer().schedule(2000)
        {
            println("ffs")
        }
    }
}
